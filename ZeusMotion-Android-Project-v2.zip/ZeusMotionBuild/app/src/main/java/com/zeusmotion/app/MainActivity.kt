package com.zeusmotion.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri

private val Background = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Panel2 = Color(0xFF252834)
private val Accent = Color(0xFF8B5CF6)
private val TextMain = Color(0xFFF4F4F7)
private val TextMuted = Color(0xFFA5A8B5)

data class EditorLayer(
    val id: Int,
    val name: String,
    val kind: String,
    val keyframes: Int = 0,
    val selected: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZeusMotionApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZeusMotionApp() {
    var layers by remember {
        mutableStateOf(
            listOf(
                EditorLayer(1, "Vídeo 1", "VÍDEO", 2, true),
                EditorLayer(2, "Texto", "TEXTO", 1),
                EditorLayer(3, "Ajustes", "EFEITO", 0)
            )
        )
    }
    var nextId by remember { mutableIntStateOf(4) }
    var selectedId by remember { mutableIntStateOf(1) }
    var playhead by remember { mutableFloatStateOf(3.5f) }
    var glow by remember { mutableFloatStateOf(0.25f) }
    var shake by remember { mutableFloatStateOf(0.10f) }
    var blur by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var importedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Projeto novo • 1080p • 30 FPS") }
    var showAddMenu by remember { mutableStateOf(false) }
    var showEffects by remember { mutableStateOf(true) }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            importedUri = uri
            status = "Mídia selecionada. Camada de vídeo pronta para edição."
            layers = layers.map { if (it.id == selectedId) it.copy(name = "Mídia importada", kind = "VÍDEO") else it }
        }
    }

    val selectedLayer = layers.firstOrNull { it.id == selectedId }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Panel,
            onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ZEUS MOTION", fontWeight = FontWeight.Black, fontSize = 18.sp, color = TextMain)
                            Text("Editor mobile • 1080p", fontSize = 11.sp, color = TextMuted)
                        }
                    },
                    actions = {
                        IconButton(onClick = { videoPicker.launch("video/*") }) {
                            Icon(Icons.Default.FolderOpen, "Importar vídeo", tint = TextMain)
                        }
                        IconButton(onClick = { status = "Projeto Zeus Motion salvo nesta sessão." }) {
                            Icon(Icons.Default.Save, "Salvar projeto", tint = TextMain)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Background)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(
                        selected = true, onClick = { showEffects = false },
                        icon = { Icon(Icons.Default.Movie, null) }, label = { Text("Editor") }
                    )
                    NavigationBarItem(
                        selected = showEffects, onClick = { showEffects = true },
                        icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Efeitos") }
                    )
                    NavigationBarItem(
                        selected = false, onClick = { status = "Exportação 1080p: renderizador de vídeo ainda será implementado." },
                        icon = { Icon(Icons.Default.Save, null) }, label = { Text("Exportar") }
                    )
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = Panel2, shape = RoundedCornerShape(8.dp)) {
                            Text("PROJETO 01", modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(status, color = TextMuted, fontSize = 10.sp, maxLines = 2)
                    }
                }
                item {
                    // Preview canvas
                    Box(
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                            .background(Color(0xFF08090D), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Movie, null, tint = Accent, modifier = Modifier.size(40.dp))
                            Text(if (importedUri == null) "PRÉ-VISUALIZAÇÃO" else "MÍDIA CARREGADA", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("16:9  •  1920 × 1080", color = TextMuted, fontSize = 11.sp)
                            if (importedUri != null) Text("Arquivo selecionado", color = Accent, fontSize = 10.sp)
                        }
                        Surface(
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
                            color = Panel2.copy(alpha = 0.95f),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)) {
                                IconButton(onClick = { playhead = (playhead + 0.5f).coerceAtMost(15f) }) {
                                    Icon(Icons.Default.PlayArrow, "Avançar", tint = TextMain)
                                }
                                Text("${playhead.toInt()}s ${(playhead % 1 * 30).toInt()}f", color = TextMain, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard("DURAÇÃO", "15 s", Modifier.weight(1f))
                        MetricCard("FPS", "30", Modifier.weight(1f))
                        MetricCard("SAÍDA", "1080p", Modifier.weight(1f))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Layers, null, tint = Accent, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("CAMADAS & TIMELINE", fontWeight = FontWeight.Bold, color = TextMain, fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        Box {
                            IconButton(onClick = { showAddMenu = true }) { Icon(Icons.Default.Add, "Adicionar camada", tint = TextMain) }
                            DropdownMenu(expanded = showAddMenu, onDismissRequest = { showAddMenu = false }) {
                                listOf("Vídeo" to "VÍDEO", "Texto" to "TEXTO", "Áudio" to "ÁUDIO", "Efeito" to "EFEITO").forEach { (label, kind) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        layers = layers + EditorLayer(nextId, "$label $nextId", kind, selected = false)
                                        selectedId = nextId
                                        nextId++
                                        showAddMenu = false
                                        status = "Camada adicionada."
                                    })
                                }
                            }
                        }
                    }
                }
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CAMADA", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("0s                         5s                        10s", color = TextMuted, fontSize = 9.sp)
                        }
                        // timeline ruler and playhead
                        Box(Modifier.fillMaxWidth().height(20.dp).background(Background, RoundedCornerShape(5.dp))) {
                            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                repeat(11) { Box(Modifier.width(1.dp).height(if (it % 5 == 0) 14.dp else 6.dp).background(TextMuted)) }
                            }
                            Box(Modifier.fillMaxHeight().fillMaxWidth(playhead / 15f).width(2.dp).background(Accent))
                        }
                        layers.forEach { layer ->
                            Row(
                                modifier = Modifier.fillMaxWidth()
                                    .background(if (layer.id == selectedId) Color(0xFF30234D) else Panel2, RoundedCornerShape(8.dp))
                                    .clickable { selectedId = layer.id }
                                    .padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.width(90.dp)) {
                                    Text(layer.name, color = TextMain, fontSize = 11.sp, maxLines = 1)
                                    Text(layer.kind, color = TextMuted, fontSize = 8.sp)
                                }
                                Box(Modifier.weight(1f).height(25.dp).background(Background, RoundedCornerShape(5.dp))) {
                                    Box(
                                        Modifier.fillMaxHeight().fillMaxWidth((0.48f + layer.id * 0.07f).coerceAtMost(1f))
                                            .background(if (layer.id == selectedId) Accent.copy(alpha = 0.75f) else Color(0xFF53627D), RoundedCornerShape(5.dp))
                                    )
                                    Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        repeat(layer.keyframes) { Text("◆", color = Color.White, fontSize = 9.sp) }
                                    }
                                }
                                IconButton(
                                    modifier = Modifier.size(30.dp),
                                    onClick = {
                                        layers = layers.map { if (it.id == layer.id) it.copy(keyframes = it.keyframes + 1) else it }
                                        selectedId = layer.id
                                        status = "Keyframe adicionado em ${layer.name}."
                                    }
                                ) { Icon(Icons.Default.Key, "Adicionar keyframe", tint = if (layer.id == selectedId) Accent else TextMuted, modifier = Modifier.size(17.dp)) }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Posição", color = TextMuted, fontSize = 10.sp)
                            Slider(value = playhead, onValueChange = { playhead = it }, valueRange = 0f..15f, modifier = Modifier.weight(1f))
                            Text("${playhead.toInt()}s", color = TextMain, fontSize = 10.sp)
                        }
                    }
                }
                if (showEffects) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tune, null, tint = Accent, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("EFEITOS BÁSICOS", fontWeight = FontWeight.Bold, color = TextMain, fontSize = 13.sp)
                        }
                    }
                    item {
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Camada selecionada: ${selectedLayer?.name ?: "Nenhuma"}", color = TextMuted, fontSize = 11.sp)
                            EffectSlider("Glow", glow, { glow = it }, "Intensidade luminosa")
                            EffectSlider("Shake", shake, { shake = it }, "Intensidade de tremor")
                            EffectSlider("Blur", blur, { blur = it }, "Desfoque")
                            EffectSlider("Zoom", zoom, { zoom = it }, "Escala da camada", 0.5f..2f)
                            Text("Os controles guardam os valores do efeito no editor. A aplicação visual no vídeo e a renderização serão implementadas na próxima etapa.", color = TextMuted, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = { videoPicker.launch("video/*") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)
                        ) {
                            Icon(Icons.Default.ContentCut, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Importar mídia", fontSize = 11.sp)
                        }
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = { status = "Configuração escolhida: exportação 1080p. Renderização ainda pendente." }
                        ) {
                            Text("Exportar 1080p", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(10.dp)).padding(10.dp)) {
        Text(label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(value, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EffectSlider(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    description: String,
    range: ClosedFloatingPointRange<Float> = 0f..1f
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(if (title == "Zoom") "${(value * 100).toInt()}%" else "${(value * 100).toInt()}%", color = Accent, fontSize = 11.sp)
        }
        Text(description, color = TextMuted, fontSize = 9.sp)
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}
