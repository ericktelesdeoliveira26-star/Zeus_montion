# Zeus Motion — MVP Android

Projeto inicial nativo Android em Kotlin + Jetpack Compose. Interface escura inspirada em editores de composição, adaptada para celular.

## O que já está implementado
- Interface de editor com painel de pré-visualização.
- Timeline visual com régua e controle de posição.
- Adicionar camadas de vídeo, texto, áudio e efeito.
- Selecionar camadas.
- Adicionar keyframes por camada (marcadores e contagem).
- Controles de parâmetros para Glow, Shake, Blur e Zoom.
- Seleção de vídeo do armazenamento usando o seletor Android.
- Configuração-alvo de projeto 1080p / 30 FPS.

## Limitações honestas desta versão
Este é um MVP de interface e estado de edição. Ainda **não** aplica os efeitos aos pixels do vídeo, não possui reprodução real do vídeo na composição, não salva um arquivo de projeto persistente e não renderiza/exporta MP4. O botão Exportar informa isso; não gera um vídeo falso. Essas funções exigem implementar um pipeline de mídia e serialização na próxima etapa.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK Platform 35
- Internet na primeira sincronização Gradle

## Gerar APK debug
1. Extraia `ZeusMotion-Android-Project.zip`.
2. Abra a pasta `ZeusMotion` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale o SDK Platform 35 e use JDK 17.
5. No menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK debug deverá ser criado em `app/build/outputs/apk/debug/app-debug.apk`.
7. Para instalar no celular, transfira o APK e permita a instalação para essa fonte nas configurações do Android, se solicitado.

## Compilar pela linha de comando
Com Android SDK configurado:
- Windows: `gradlew.bat assembleDebug`
- Linux/macOS: `./gradlew assembleDebug`

O wrapper Gradle não está incluído neste pacote; o Android Studio consegue importar e sincronizar o projeto, ou você pode gerar o wrapper localmente com Gradle instalado (`gradle wrapper`) antes de usar o comando.

## Próximas etapas técnicas
1. Reprodução real de mídia no preview (Media3 ExoPlayer).
2. Persistência de projeto JSON.
3. Efeitos reais em preview (RenderEffect / shader) e keyframes interpolados.
4. Renderização/exportação MP4 com MediaCodec/Media3 Transformer ou pipeline equivalente.
5. Testes em aparelhos de diferentes capacidades e otimização de memória.

## Build APK pelo celular usando GitHub Actions
O projeto inclui `.github/workflows/build-apk.yml` para compilar na nuvem sem Android Studio local.
1. No navegador do celular, entre em GitHub e crie um repositório novo.
2. Envie os arquivos desta pasta para o repositório, mantendo a estrutura de pastas. Inclua a pasta oculta `.github/workflows` e o arquivo `build-apk.yml`.
3. Abra a aba **Actions**, selecione **Build Zeus Motion APK** e toque em **Run workflow**. Se não aparecer, faça um commit na branch `main` para disparar o workflow.
4. Quando terminar com sucesso, abra a execução e baixe o artefato **ZeusMotion-debug-apk**. Extraia o ZIP do artefato para obter `app-debug.apk`.
5. Instale o APK no Android. O sistema pode pedir autorização para instalar apps dessa origem.

A compilação na nuvem depende de uma conta GitHub e de o workflow concluir sem erros. Não há APK pré-compilado neste pacote.
